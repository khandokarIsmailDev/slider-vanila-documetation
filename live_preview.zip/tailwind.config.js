/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,js}", // Adjust the path as needed for your project structure
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
